export function formatDate(dateString) {
  const d = new Date(dateString);
  return d.toLocaleString();
}