import React, { useEffect, useRef, useState } from 'react';

export default function VideoCall({ socket, roomId, onCallEnd }) {
  const localVideoRef = useRef();
  const remoteVideoRef = useRef();
  const [pc, setPc] = useState(null);

  useEffect(() => {
    const peerConnection = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    });

    setPc(peerConnection);

    // Get user media
    navigator.mediaDevices.getUserMedia({ video: true, audio: true }).then(stream => {
      localVideoRef.current.srcObject = stream;
      stream.getTracks().forEach(track => peerConnection.addTrack(track, stream));
    });

    // Handle remote stream
    peerConnection.ontrack = event => {
      remoteVideoRef.current.srcObject = event.streams[0];
    };

    // Handle ICE candidates
    peerConnection.onicecandidate = event => {
      if (event.candidate) {
        socket.emit('webrtc-ice-candidate', { roomId, candidate: event.candidate });
      }
    };

    // Listen for signaling messages
    socket.on('webrtc-offer', async ({ sdp }) => {
      await peerConnection.setRemoteDescription(new RTCSessionDescription(sdp));
      const answer = await peerConnection.createAnswer();
      await peerConnection.setLocalDescription(answer);
      socket.emit('webrtc-answer', { roomId, sdp: peerConnection.localDescription });
    });

    socket.on('webrtc-answer', async ({ sdp }) => {
      await peerConnection.setRemoteDescription(new RTCSessionDescription(sdp));
    });

    socket.on('webrtc-ice-candidate', async ({ candidate }) => {
      try {
        await peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
      } catch (err) {
        console.error(err);
      }
    });

    // Create offer to initiate call if caller
    socket.emit('join-call-room', { roomId });
    socket.on('start-call', async () => {
      const offer = await peerConnection.createOffer();
      await peerConnection.setLocalDescription(offer);
      socket.emit('webrtc-offer', { roomId, sdp: peerConnection.localDescription });
    });

    return () => {
      peerConnection.close();
      socket.off('webrtc-offer');
      socket.off('webrtc-answer');
      socket.off('webrtc-ice-candidate');
      socket.off('start-call');
      onCallEnd();
    };
  }, [roomId, socket, onCallEnd]);

  return (
    <div className="flex flex-col items-center gap-2">
      <video ref={localVideoRef} autoPlay muted playsInline className="w-48 h-48 bg-black rounded" />
      <video ref={remoteVideoRef} autoPlay playsInline className="w-48 h-48 bg-black rounded" />
      <button
        onClick={() => {
          socket.emit('end-call', { roomId });
          onCallEnd();
        }}
        className="mt-4 px-4 py-2 bg-red-600 text-white rounded"
      >
        End Call
      </button>
    </div>
  );
}