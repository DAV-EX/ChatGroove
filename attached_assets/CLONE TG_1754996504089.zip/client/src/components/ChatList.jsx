import React from 'react';

export default function ChatList({ chats, currentUserId, activeChatId, setActiveChat }) {
  return (
    <div>
      {chats.map(chat => {
        const otherUser = chat.participants.find(p => p._id !== currentUserId);
        return (
          <div
            key={chat._id}
            onClick={() => setActiveChat(chat)}
            className={`p-3 cursor-pointer ${activeChatId === chat._id ? 'bg-blue-200' : ''}`}
          >
            {otherUser?.displayName || otherUser?.email || 'Unknown'}
          </div>
        );
      })}
    </div>
  );
}