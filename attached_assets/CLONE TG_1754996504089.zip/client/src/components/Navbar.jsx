import React from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-gray-800 text-white flex justify-between items-center p-4">
      <h1 className="font-bold text-xl cursor-pointer" onClick={() => navigate('/chat')}>
        Telegram Clone
      </h1>
      <div className="flex items-center gap-4">
        <span>{user?.displayName || user?.email}</span>
        <button onClick={handleLogout} className="bg-red-600 px-3 py-1 rounded hover:bg-red-700">
          Logout
        </button>
      </div>
    </nav>
  );
}