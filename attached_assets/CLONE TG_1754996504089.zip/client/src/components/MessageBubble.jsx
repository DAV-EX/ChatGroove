import React from 'react';
import { formatDate } from '../utils/formatDate';

export default function MessageBubble({ message, isOwn }) {
  return (
    <div
      className={`max-w-xs p-2 rounded mb-1 ${isOwn ? 'bg-blue-400 text-white ml-auto' : 'bg-gray-300'}`}
    >
      <div className="text-xs font-semibold">{message.sender.displayName || message.sender.email}</div>
      {message.text && <p>{message.text}</p>}
      {message.fileUrl && (
        <a href={message.fileUrl} target="_blank" rel="noopener noreferrer" className="underline text-sm">
          View File
        </a>
      )}
      <div className="text-xs text-right">{formatDate(message.createdAt)}</div>
    </div>
  );
}