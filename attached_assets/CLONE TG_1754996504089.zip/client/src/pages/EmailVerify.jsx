import React, { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import api from '../utils/api';

export default function EmailVerify() {
  const [searchParams] = useSearchParams();
  const [msg, setMsg] = useState('Verifying...');
  const token = searchParams.get('token');

  useEffect(() => {
    if (!token) {
      setMsg('Invalid verification link');
      return;
    }
    async function verify() {
      try {
        await api.get(`/auth/verify-email?token=${token}`);
        setMsg('Email verified! Please wait for admin approval.');
      } catch {
        setMsg('Verification failed or expired.');
      }
    }
    verify();
  }, [token]);

  return (
    <div className="container mx-auto max-w-md mt-20 p-4 border rounded shadow text-center">
      <p>{msg}</p>
      <Link to="/login" className="text-blue-600 underline mt-4 block">Go to Login</Link>
    </div>
  );
}