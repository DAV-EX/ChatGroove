import React from 'react';
import { useAuth } from '../context/AuthContext';

export default function PendingApproval() {
  const { user } = useAuth();

  return (
    <div className="container mx-auto max-w-md mt-20 p-4 border rounded shadow text-center">
      <h2 className="text-xl font-bold mb-4">Account Pending Approval</h2>
      <p>Your phone number is pending admin approval.</p>
      <p className="mt-2">Email: {user?.email}</p>
      <p>Status: {user?.status}</p>
      <p>Please wait for admin to approve your account before you can chat.</p>
    </div>
  );
}