import React, { useEffect, useState } from 'react';
import api from '../utils/api';

export default function AdminPanel() {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    async function fetchUsers() {
      const res = await api.get('/users');
      setUsers(res.data.filter(u => u.status === 'pending'));
    }
    fetchUsers();
  }, []);

  const approve = async userId => {
    await api.put(`/users/approve/${userId}`);
    setUsers(users.filter(u => u._id !== userId));
  };

  const reject = async userId => {
    await api.put(`/users/reject/${userId}`);
    setUsers(users.filter(u => u._id !== userId));
  };

  return (
    <div className="container mx-auto max-w-xl mt-10 p-4 border rounded shadow">
      <h2 className="text-xl font-bold mb-4">Admin Panel - Approve Users</h2>
      {users.length === 0 && <p>No users pending approval</p>}
      {users.map(user => (
        <div key={user._id} className="flex justify-between items-center p-2 border-b">
          <div>
            <p><strong>{user.displayName || user.email}</strong></p>
            <p>Phone: {user.phone || 'N/A'}</p>
            <p>Status: {user.status}</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => approve(user._id)} className="bg-green-600 text-white px-3 rounded">Approve</button>
            <button onClick={() => reject(user._id)} className="bg-red-600 text-white px-3 rounded">Reject</button>
          </div>
        </div>
      ))}
    </div>
  );
}