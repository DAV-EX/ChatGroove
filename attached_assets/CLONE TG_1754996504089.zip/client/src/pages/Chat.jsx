import React, { useEffect, useState } from 'react';
import io from 'socket.io-client';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';

const socket = io();

export default function Chat() {
  const { user } = useAuth();
  const [chats, setChats] = useState([]);
  const [activeChat, setActiveChat] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    async function fetchChats() {
      const res = await api.get('/chats');
      setChats(res.data);
      if (res.data.length) setActiveChat(res.data[0]);
    }
    fetchChats();
  }, []);

  useEffect(() => {
    if (!activeChat) return;
    socket.emit('joinChat', { chatId: activeChat._id });

    async function fetchMessages() {
      // For simplicity, fetch messages by chatId (implement API later)
      // Assume backend has endpoint /messages/:chatId (not yet coded)
      const res = await api.get(`/messages/${activeChat._id}`);
      setMessages(res.data);
    }
    fetchMessages();

    socket.on('newMessage', msg => {
      if (msg.chat === activeChat._id) {
        setMessages(prev => [...prev, msg]);
      }
    });

    return () => {
      socket.off('newMessage');
    };
  }, [activeChat]);

  const sendMessage = () => {
    if (!input.trim()) return;
    socket.emit('sendMessage', {
      chatId: activeChat._id,
      senderId: user._id,
      text: input.trim()
    });
    setInput('');
  };

  return (
    <div className="flex h-screen">
      <aside className="w-1/4 border-r overflow-auto">
        <h2 className="p-4 font-bold">Chats</h2>
        {chats.map(chat => (
          <div
            key={chat._id}
            className={`p-3 cursor-pointer ${activeChat?._id === chat._id ? 'bg-blue-200' : ''}`}
            onClick={() => setActiveChat(chat)}
          >
            {chat.participants.filter(p => p._id !== user._id)[0]?.displayName || 'Unknown'}
          </div>
        ))}
      </aside>
      <main className="flex-1 flex flex-col">
        <div className="flex-1 overflow-auto p-4 space-y-2">
          {messages.map(msg => (
            <div
              key={msg._id}
              className={`max-w-xs p-2 rounded ${msg.sender._id === user._id ? 'bg-blue-400 text-white ml-auto' : 'bg-gray-300'}`}
            >
              <strong>{msg.sender.displayName || msg.sender.email}</strong>
              <p>{msg.text}</p>
            </div>
          ))}
        </div>
        <footer className="p-4 border-t flex gap-2">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Type a message"
            className="flex-grow border p-2 rounded"
          />
          <button onClick={sendMessage} className="bg-blue-600 text-white px-4 rounded">Send</button>
        </footer>
      </main>
    </div>
  );
}