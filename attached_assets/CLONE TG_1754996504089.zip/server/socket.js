const Chat = require('./models/Chat');
const Message = require('./models/Message');
const User = require('./models/User');

module.exports = (io, socket) => {
  console.log('Socket connected:', socket.id);

  socket.on('joinChat', async ({ chatId }) => {
    socket.join(chatId);
  });

  socket.on('sendMessage', async ({ chatId, senderId, text, fileUrl }) => {
    try {
      const message = new Message({ chat: chatId, sender: senderId, text, fileUrl });
      await message.save();

      await Chat.findByIdAndUpdate(chatId, { lastMessage: message._id, updatedAt: new Date() });

      io.to(chatId).emit('newMessage', await message.populate('sender', 'displayName avatar'));
    } catch (err) {
      console.error(err);
    }
  });

  socket.on('disconnect', () => {
    console.log('Socket disconnected:', socket.id);
  });
};