const nodemailer = require('nodemailer');
const config = require('../config');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: config.emailUser,
    pass: config.emailPass
  }
});

module.exports.sendVerificationEmail = async (to, link) => {
  await transporter.sendMail({
    from: `"Telegram Clone" <${config.emailUser}>`,
    to,
    subject: 'Verify your email',
    html: `<p>Welcome! Click <a href="${link}">here</a> to verify your email.</p>`
  });
};