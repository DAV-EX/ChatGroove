const Minio = require('minio');
const config = require('../config');

const client = new Minio.Client({
  endPoint: config.minio.endpoint,
  port: config.minio.port,
  useSSL: false,
  accessKey: config.minio.accessKey,
  secretKey: config.minio.secretKey
});

const ensureBucketExists = async () => {
  try {
    const exists = await client.bucketExists(config.minio.bucket);
    if (!exists) await client.makeBucket(config.minio.bucket);
  } catch (err) {
    console.error('MinIO bucket error:', err);
  }
};

ensureBucketExists();

module.exports = { client };