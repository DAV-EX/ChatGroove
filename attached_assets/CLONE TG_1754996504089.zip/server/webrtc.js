// WebRTC signaling logic via Socket.IO
module.exports = (io, socket) => {
  socket.on('join-call-room', ({ roomId }) => {
    socket.join(roomId);
    const clients = io.sockets.adapter.rooms.get(roomId);
    if (clients.size === 1) {
      socket.emit('start-call'); // First client triggers call offer
    }
  });

  socket.on('webrtc-offer', ({ roomId, sdp }) => {
    socket.to(roomId).emit('webrtc-offer', { sdp });
  });

  socket.on('webrtc-answer', ({ roomId, sdp }) => {
    socket.to(roomId).emit('webrtc-answer', { sdp });
  });

  socket.on('webrtc-ice-candidate', ({ roomId, candidate }) => {
    socket.to(roomId).emit('webrtc-ice-candidate', { candidate });
  });

  socket.on('end-call', ({ roomId }) => {
    socket.to(roomId).emit('call-ended');
    socket.leave(roomId);
  });
};