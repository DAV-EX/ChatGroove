const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const sendVerificationEmail = require('../utils/email').sendVerificationEmail;
const config = require('../config');
const router = express.Router();

router.post('/register',
  body('email').isEmail(),
  body('password').isLength({ min: 6 }),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { email, password } = req.body;
    try {
      let user = await User.findOne({ email });
      if (user) return res.status(400).json({ msg: 'User already exists' });

      const hashed = await bcrypt.hash(password, 10);
      user = new User({ email, password: hashed });
      await user.save();

      const token = jwt.sign({ id: user._id }, config.jwtSecret, { expiresIn: '1d' });
      const verificationLink = `${process.env.CLIENT_URL}/verify-email?token=${token}`;

      await sendVerificationEmail(email, verificationLink);

      res.json({ msg: 'Registration successful. Please verify your email.' });
    } catch (err) {
      console.error(err);
      res.status(500).json({ msg: 'Server error' });
    }
  }
);

router.get('/verify-email', async (req, res) => {
  const token = req.query.token;
  if (!token) return res.status(400).send('Invalid token');

  try {
    const decoded = jwt.verify(token, config.jwtSecret);
    const user = await User.findById(decoded.id);
    if (!user) return res.status(400).send('User not found');

    user.verifiedEmail = true;
    user.status = 'pending'; // phone verification pending
    await user.save();

    res.send('Email verified. Please wait for admin to approve your phone number.');
  } catch (err) {
    res.status(400).send('Invalid or expired token');
  }
});

router.post('/login',
  body('email').isEmail(),
  body('password').exists(),
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { email, password } = req.body;
    try {
      const user = await User.findOne({ email });
      if (!user) return res.status(400).json({ msg: 'Invalid credentials' });
      if (!user.verifiedEmail) return res.status(403).json({ msg: 'Email not verified' });
      if (user.status !== 'active') return res.status(403).json({ msg: 'Account not active' });

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) return res.status(400).json({ msg: 'Invalid credentials' });

      const token = jwt.sign({ id: user._id }, config.jwtSecret, { expiresIn: '7d' });
      res.json({ token, user: { email: user.email, displayName: user.displayName, phone: user.phone, avatar: user.avatar, bio: user.bio, isAdmin: user.isAdmin } });
    } catch (err) {
      console.error(err);
      res.status(500).json({ msg: 'Server error' });
    }
  }
);

module.exports = router;