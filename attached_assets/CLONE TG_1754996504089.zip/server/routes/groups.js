const express = require('express');
const authMiddleware = require('../middleware/auth');
const Group = require('../models/Group');
const router = express.Router();

// Get groups user is in
router.get('/', authMiddleware, async (req, res) => {
  const groups = await Group.find({ members: req.user._id }).populate('admins members', 'displayName email');
  res.json(groups);
});

// Create group
router.post('/create', authMiddleware, async (req, res) => {
  const { name, members } = req.body;
  if (!name) return res.status(400).json({ msg: 'Group name required' });
  const group = new Group({
    name,
    members: [...new Set([req.user._id, ...(members || [])])],
    admins: [req.user._id]
  });
  await group.save();
  res.json(group);
});

// Add member (admin only)
router.put('/:groupId/add', authMiddleware, async (req, res) => {
  const group = await Group.findById(req.params.groupId);
  if (!group) return res.status(404).json({ msg: 'Group not found' });
  if (!group.admins.includes(req.user._id)) return res.status(403).json({ msg: 'Admins only' });
  const { memberId } = req.body;
  if (!memberId) return res.status(400).json({ msg: 'Member ID required' });
  if (!group.members.includes(memberId)) {
    group.members.push(memberId);
    await group.save();
  }
  res.json(group);
});

module.exports = router;