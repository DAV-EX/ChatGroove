const express = require('express');
const authMiddleware = require('../middleware/auth');
const adminMiddleware = require('../middleware/admin');
const User = require('../models/User');
const router = express.Router();

// Get current user profile
router.get('/me', authMiddleware, async (req, res) => {
  res.json(req.user);
});

// Get all users (admin only)
router.get('/', authMiddleware, adminMiddleware, async (req, res) => {
  const users = await User.find().select('-password');
  res.json(users);
});

// Update phone number (pending admin approval)
router.put('/phone', authMiddleware, async (req, res) => {
  const { phone } = req.body;
  if (!phone) return res.status(400).json({ msg: 'Phone number required' });
  req.user.phone = phone;
  req.user.status = 'pending'; // Reset status to pending admin approval
  await req.user.save();
  res.json({ msg: 'Phone number submitted, awaiting approval' });
});

// Admin approves phone number
router.put('/approve/:userId', authMiddleware, adminMiddleware, async (req, res) => {
  const user = await User.findById(req.params.userId);
  if (!user) return res.status(404).json({ msg: 'User not found' });
  user.status = 'active';
  await user.save();
  res.json({ msg: 'User approved' });
});

// Admin rejects phone number
router.put('/reject/:userId', authMiddleware, adminMiddleware, async (req, res) => {
  const user = await User.findById(req.params.userId);
  if (!user) return res.status(404).json({ msg: 'User not found' });
  user.status = 'banned';
  await user.save();
  res.json({ msg: 'User rejected' });
});

module.exports = router;