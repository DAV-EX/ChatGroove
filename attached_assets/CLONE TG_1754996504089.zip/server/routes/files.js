const express = require('express');
const multer = require('multer');
const authMiddleware = require('../middleware/auth');
const minioClient = require('../utils/fileStorage').client;
const router = express.Router();

const storage = multer.memoryStorage();
const upload = multer({ storage });

router.post('/upload', authMiddleware, upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ msg: 'No file uploaded' });

  const fileName = `${Date.now()}_${req.file.originalname}`;

  try {
    await minioClient.putObject(
      process.env.MINIO_BUCKET,
      fileName,
      req.file.buffer,
      req.file.size,
      { 'Content-Type': req.file.mimetype }
    );

    const protocol = process.env.MINIO_USE_SSL === 'true' ? 'https' : 'http';
    const portPart = process.env.MINIO_PORT ? `:${process.env.MINIO_PORT}` : '';
    const fileUrl = `${protocol}://${process.env.MINIO_ENDPOINT}${portPart}/${process.env.MINIO_BUCKET}/${fileName}`;

    res.json({ fileUrl });
  } catch (err) {
    console.error('File upload error:', err);
    res.status(500).json({ msg: 'File upload failed' });
  }
});

module.exports = router;