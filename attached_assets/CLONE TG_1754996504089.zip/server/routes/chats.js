const express = require('express');
const authMiddleware = require('../middleware/auth');
const Chat = require('../models/Chat');
const Message = require('../models/Message');
const User = require('../models/User');
const router = express.Router();

// Get chats for logged in user
router.get('/', authMiddleware, async (req, res) => {
  const chats = await Chat.find({ participants: req.user._id })
    .populate('participants', 'displayName email avatar')
    .populate('lastMessage');
  res.json(chats);
});

// Create or get existing chat between two users
router.post('/create', authMiddleware, async (req, res) => {
  const { userId } = req.body;
  if (!userId) return res.status(400).json({ msg: 'User ID required' });

  let chat = await Chat.findOne({ participants: { $all: [req.user._id, userId] } });
  if (chat) return res.json(chat);

  chat = new Chat({ participants: [req.user._id, userId] });
  await chat.save();
  res.json(chat);
});

module.exports = router;